Hints for running the NSS test suite:

- all.sh is used to run all tests

- if your host is not registered with DNS you may use:
  HOST=localhost DOMSUF=localdomain ./all.sh
