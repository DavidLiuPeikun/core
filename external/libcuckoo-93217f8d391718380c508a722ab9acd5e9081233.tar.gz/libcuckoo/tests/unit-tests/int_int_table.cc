extern "C" {
#include "int_int_table.h"
}

#include <libcuckoo-c/cuckoo_table_template.cc>
