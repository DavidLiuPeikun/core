// This file will be the entry point for the test runner
#define CATCH_CONFIG_MAIN
#include <catch.hpp>
