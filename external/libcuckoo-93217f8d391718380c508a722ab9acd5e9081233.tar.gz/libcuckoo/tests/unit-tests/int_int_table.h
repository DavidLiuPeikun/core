#ifndef INT_INT_TABLE_H
#define INT_INT_TABLE_H

#define CUCKOO_TABLE_NAME int_int_table
#define CUCKOO_KEY_TYPE int
#define CUCKOO_MAPPED_TYPE int

#include <libcuckoo-c/cuckoo_table_template.h>

#endif // INT_INT_TABLE_H
